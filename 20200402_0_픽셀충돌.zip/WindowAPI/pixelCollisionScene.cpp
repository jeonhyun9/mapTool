#include "stdafx.h"
#include "pixelCollisionScene.h"

HRESULT pixelCollisionScene::init()
{
	//��׶���, �� �̹��� �ʱ�ȭ
	_mountain = IMAGEMANAGER->findImage("mountain");
	_mountain2 = IMAGEMANAGER->findImage("mountain");

	_ball = IMAGEMANAGER->findImage("ball");
	bg = RectMake(0, 0, 2000, WINSIZEY);
	angle = 0;
	speed = 6.0f;
	gravity = 0;

	_x = 150;
	_virtualX = 150;
	_y = 100;

	_mountainX = 0;
	_mountainY = 0;

	temp.x = 0;

	_mountain->setX(0);
	_mountain->setY(0);

	//�� ��ġ �ʱ�ȭ
	_x = 150;
	_y = 100;
	_rc = RectMakeCenter(_x, _y, _ball->getWidth(), _ball->getHeight());

	//Y������ Ž��(���� �ϴܿ��� �˻���)
	_probeY = _y + _ball->getHeight() / 2;

	return S_OK;
}

void pixelCollisionScene::release()
{
}

void pixelCollisionScene::update()
{
	if (fire == false)
	{
		_x = 150;
		_y = 100;
	}

	if (INPUT->GetKeyDown(VK_SPACE))
	{
		fire = true;
	}
	if (INPUT->GetKey(VK_RIGHT))
	{
		_x += 3.0f;
	}
	//���� ��Ʈ �����̱�
	_rc = RectMakeCenter(_x, _y, 60, 60);
	_probeY = _y + _ball->getHeight() / 2;

	/*�̺κ��� �ȼ��浹�� �ٽ�*/
	for (int i = _probeY - 50; i < _probeY ; i++)
	{
		COLORREF color = GetPixel(_mountain->getMemDC(), _virtualX, i);
		int r = GetRValue(color);
		int g = GetGValue(color);
		int b = GetBValue(color);

		if (!(r == 255 && g == 0 && b == 255))
		{
			bg.left = 0;
			fire = false;
			this->generateMazentaCircle();
			_virtualX = 150;
			gravity = 0;
			
			break;
		}
	}

	_rcSquare = RectMakeCenter(_ptMouse.x, _ptMouse.y, 100, 100);
	this->ballMove();
}

void pixelCollisionScene::render()
{
	//��׶��� ����	
	_mountain->render(getMemDC(),bg.left,bg.top,_mountainX,_mountainY,2000,WINSIZEY);


	//�� �̹��� ����
	if (fire == true)
	{
		_ball->render(getMemDC(), _rc.left, _rc.top);
	}
	
	EllipseMakeCenter(getMemDC(), 0, 100, 100, 100);
	LineMake(getMemDC(), 0, 100, 150, 100);
	
	if (INPUT->GetKeyDown(VK_RBUTTON))
	{
		this->generateMazentaCircle();
	}
	else
	{
		Rectangle(getMemDC(), _rcSquare);
	}

	//������
	if (INPUT->GetToggleKey('A'))
	{
		//�浹�� �����簢��
		RECT rc = RectMakeCenter(_x, _probeY, 10, 10);
		Rectangle(getMemDC(), rc);
	}


	SetTextColor(getMemDC(), RGB(255, 0, 0));
	TextOut(getMemDC(), 10, 10, "�ȼ��浹", strlen("�ȼ��浹"));

}

void pixelCollisionScene::generateMazentaCircle()
{
	HPEN MyPen, OldPen;
	HBRUSH mazenta = CreateSolidBrush(RGB(255, 0, 255));

	MyPen = CreatePen(PS_SOLID, 5, RGB(255, 0, 255));
	OldPen = (HPEN)SelectObject(_mountain->getMemDC(), MyPen);

	SelectObject(_mountain->getMemDC(), mazenta);

	EllipseMakeCenter(_mountain->getMemDC(), _virtualX, _y, 100, 100);

	DeleteObject(mazenta);
	DeleteObject(OldPen);
}

void pixelCollisionScene::ballMove()
{
	if (fire==true)
	{
		gravity += 0.05f;
		
		if (_x >= WINSIZEX / 2)
		{
			//_x += cosf(angle) * speed;
			//_mountain->setX(_mountain->getX()-cosf(angle) * speed);
			bg.left -= cosf(angle) * speed;
			bg.right -= cosf(angle) * speed;
		}
		else
		{
			_x += cosf(angle) * speed;
		}
		_virtualX += cosf(angle) * speed;
		_y += -sinf(angle) * speed + gravity;

		//.0
		//_mountain->setX(_mountain->getX() - cosf(angle) * speed);
	}
	
}




