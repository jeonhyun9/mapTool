#pragma once
#include "gameNode.h"
enum State
{
	_IDLE,
	_RUN,
	_JUMP,
	_FALL,
	_GRAB,
	_ATTACK,

};


struct tagPlayer
{
	RECT rc;

	bool isRight;

	State state;

	float x;
	float y;
	float height;
	float width;
	float angle;
	float speed;
	float jumpspeed;
	float walljumpspeed;
};


class grabWall :public gameNode
{
private:
	tagPlayer player;
	RECT camera;
	RECT bg;
	image* bg_wall;
	image* player_run;
	image* player_idle;
	image* player_jump;
	image* player_fall;
	image* player_grab;
	image* player_attack;
	image* player_attack_shadow;
	image* player_attack_shadow2;
	image* player_attack_shadow3;
	image* player_slash;
	
	int jumpCount;
	int wallJumpCount;
	int attackCount;

	float gravity;

	float bgX;
	float bgY;


	float findleft;
	float findright;
	float findbottom;
	float findtop;

	float currentLeftWallX;
	float currentRightWallX;

	int frameIdx;
	int shadowframeIdx1;
	int shadowframeIdx2;
	int shadowframeIdx3;

	int slashFrameIdx;
	int frameCnt;

	bool JUMP;
	bool FALL;
	bool GRAB;
	bool WALLJUMP;
	bool STAND_FLOOR;
	bool STAND_WALL;
	bool WALLCRASH_LEFT;
	bool WALLCRASH_RIGHT;
	bool WALLCRASH_BOTTOM;
	bool WALLCRASH_TOP;

	int _alpha;
	int _count;

	char str[100];

public:
	HRESULT init();
	void update();
	void release();
	void render();

	void animation();

	void floorSet();

	void pixelCollisionLeft();

	void pixelCollisionRight();

	void pixelCoiilsionBottom();

	void pixelCoiilsionTop();

	grabWall() {}
	~grabWall() {}
};

