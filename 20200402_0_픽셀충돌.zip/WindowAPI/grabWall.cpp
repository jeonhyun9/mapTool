#include "stdafx.h"
#include "grabWall.h"

HRESULT grabWall::init()
{
	bg_wall = IMAGEMANAGER->findImage("bg_wall");
	player_run = IMAGEMANAGER->findImage("player_run");
	player_idle = IMAGEMANAGER->findImage("player_idle");
	player_jump = IMAGEMANAGER->findImage("player_flip");
	player_fall = IMAGEMANAGER->findImage("player_fall");
	player_grab = IMAGEMANAGER->findImage("player_grab");
	player_attack = IMAGEMANAGER->findImage("player_attack");
	player_slash = IMAGEMANAGER->findImage("player_slash");
	player_attack_shadow = IMAGEMANAGER->findImage("player_attack_shadow");
	player_attack_shadow2 = IMAGEMANAGER->findImage("player_attack_shadow2");
	player_attack_shadow3 = IMAGEMANAGER->findImage("player_attack_shadow3");

	bgX = bgY = 0;

	_alpha = 255;
	_count = 0;

	player.width = 48;
	player.height = 70;
	player.angle = PI / 2;
	player.speed = 10.0f;
	player.jumpspeed = 7.0f;
	player.walljumpspeed = 5.0f;
	player.x = WINSIZEX / 2;
	player.y = WINSIZEY - player.height / 2;
	player.isRight = true;

	frameCnt = frameIdx = 0;

	player.state = _IDLE;

	jumpCount = wallJumpCount = slashFrameIdx = 0;
	gravity = 0;


	JUMP = false;
	FALL = false;
	GRAB = false;
	WALLJUMP = false;
	WALLCRASH_LEFT = false;
	WALLCRASH_RIGHT = false;
	WALLCRASH_BOTTOM = false;
	WALLCRASH_TOP = false;
	STAND_WALL = false;
	STAND_FLOOR = true;

	return S_OK;
}

void grabWall::update()
{
	player.rc = RectMakeCenter(player.x, player.y, player.width, player.height);
	camera = RectMakeCenter((player.rc.left - player.width / 2) - bgX, (player.rc.top) - bgY, 300, 300);
	
	findleft = player.x - player.width / 2;
	findright = player.x + player.width / 2;
	findbottom = player.y + player.height / 2;
	findtop = player.y - player.height / 2;

	if (INPUT->GetKeyDown('Z'))
	{
		player.state = _ATTACK;
		attackCount = 0;
		frameCnt = 0;

		switch (player.isRight)
		{
		case true:frameIdx = 0;
			slashFrameIdx = 0;
			shadowframeIdx1 = 0;
			shadowframeIdx2 = 0;
			shadowframeIdx3 = 0;
			break;
		case false:frameIdx = 7;
			slashFrameIdx = 6;
			break;
		}
	}

	if (player.state == _ATTACK)
	{
		attackCount++;
		if (attackCount % 28 == 0)
		{
			player.state = _IDLE;
		}
	}

	if (INPUT->GetKey(VK_LEFT) && !GRAB)
	{
		if (WALLCRASH_LEFT == false)
		{
			//if (player.state != _RUN)frameCnt = 0;
			player.state = _RUN;
			player.isRight = false;
			player.angle = PI - 1;
			player.x += cosf(player.angle) * player.speed;
			if (camera.left < 0 && bgX >= 0)
			{
				bgX += cosf(player.angle) * player.speed;
			}
		}
	}
	if (INPUT->GetKeyUp(VK_LEFT) && !GRAB)
	{
		player.state = _IDLE;
	}

	if (INPUT->GetKey(VK_RIGHT) && !GRAB)
	{
		if (WALLCRASH_RIGHT == false)
		{
			//if (player.state != _RUN)frameCnt = 0;
			player.state = _RUN;
			player.isRight = true;
			player.angle = 1;
			player.x += cosf(player.angle) * player.speed;
			if (camera.right > WINSIZEX && bgX <= 600)
			{
				bgX += cosf(player.angle) * player.speed;
			}
		}	
	}
	if (INPUT->GetKeyUp(VK_RIGHT) && !GRAB)
	{
		player.state = _IDLE;
	}

	if (INPUT->GetKey('Q'))
	{
		if (WALLCRASH_LEFT == true || WALLCRASH_RIGHT == true)
		{
			player.state = _GRAB;
			GRAB = true;
			FALL = false;
		}
	}

	if (INPUT->GetKeyUp('Q') && GRAB == true)
	{
		if (INPUT->GetKey(VK_RIGHT) || INPUT->GetKey(VK_LEFT))
		{
			gravity = 0;
			wallJumpCount = 0;
			WALLJUMP = true;
			GRAB = false;
		}
		else
		{
			gravity = 10;
			GRAB = false;
			FALL = true;
		}

	}

	if (WALLJUMP == true && player.y - player.height / 2 > 0)
	{
		wallJumpCount++;
		if(WALLCRASH_LEFT==true)player.angle = 1;
		if(WALLCRASH_RIGHT==true)player.angle = PI - 1;
		player.y += -sinf(player.angle) * player.walljumpspeed;
	}

	if (INPUT->GetKeyDown(VK_SPACE))
	{
		gravity = 0;
		jumpCount = 0;
		GRAB = false;
		JUMP = true;
		FALL = false;
	}

	//����
	if (JUMP == true)
	{
		player.state = _JUMP;
		if (WALLCRASH_TOP == false)
		{
			jumpCount++;
			player.y += -sinf(player.angle) * player.jumpspeed;
		}

		if (WALLCRASH_TOP == true)
		{
			gravity = 10;
			FALL = true;
			JUMP = false;
		}

	}

	//�߶��Ǵ� ����
	if (JUMP == true && jumpCount % 20 == 0)
	{
		frameIdx = 0;
		FALL = true;
		JUMP = false;
	}

	if (WALLJUMP == true && wallJumpCount % 20 == 0)
	{
		FALL = true;
		WALLJUMP = false;
	}

	//�߶�
	if (FALL == true)
	{
		player.state = _FALL;
		

		if (player.y + player.height / 2 + 10 >= WINSIZEY)
		{
			player.state = _IDLE;
			this->floorSet();
		}
		if (WALLCRASH_BOTTOM == true)
		{
			player.state = _IDLE;
			FALL = false;
			STAND_WALL = true;
			jumpCount = 0;
			wallJumpCount = 0;
			gravity = 0;
		}
		else
		{
			gravity += 0.5f;
			player.y += -sinf(player.angle) * player.jumpspeed + gravity;
		}
		
	}

	if (STAND_WALL == true && WALLCRASH_BOTTOM == false && FALL==false)
	{
		FALL = true;
		STAND_WALL = false;
	}

	_count++;
	if (_count % 2 == 0)
	{
		_alpha--;
		if (_alpha <= 0) _alpha = 0;
	}
	

	this->pixelCollisionLeft();
	this->pixelCollisionRight();
	this->pixelCoiilsionBottom();
	this->pixelCoiilsionTop();
	this->animation();

}

void grabWall::release()
{
}

void grabWall::render()
{
	bg_wall->render(getMemDC(), -bgX,-bgY);


	//Rectangle(getMemDC(), camera);

	switch (player.state)
	{
	case _IDLE:
		player_idle->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX, (player.rc.top) -bgY);
		break;
	case _RUN:
		player_run->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX, (player.rc.top + 10) - bgY);
		break;
	case _JUMP:
		player_jump->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX, player.rc.top + 10);
		break;
	case _FALL:
		if (player.isRight == true)
		{
			player_fall->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX +10, (player.rc.top) - bgY);
		}
		else
		{
			player_fall->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX +20, (player.rc.top) - bgY);
		}
		break;
	case _GRAB:
		if (player.isRight == true)
		{
			player_grab->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX + 20, (player.rc.top) - bgY);
		}
		else
		{
			player_grab->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX - 5, (player.rc.top) - bgY);
		}
		break;
	case _ATTACK:
		if (shadowframeIdx3 - 3 >= 0)
		{
			player_attack_shadow3->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX - 30, (player.rc.top) - bgY - 15);
		}
		if (shadowframeIdx2 - 2>= 0)
		{
			player_attack_shadow2->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX - 20, (player.rc.top) - bgY - 15);
		}
		if (shadowframeIdx1 - 1 >= 0)
		{
			player_attack_shadow->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX - 10, (player.rc.top) - bgY - 15);
		}
		

		player_attack->alphaframeRender(getMemDC(), (player.rc.left - player.width / 2) - bgX, (player.rc.top) - bgY - 20, _alpha);
		
		if (player.isRight == true)
		{
			player_slash->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX, (player.rc.top) - bgY - 30);
		}
		else
		{
			player_slash->frameRender(getMemDC(), (player.rc.left - player.width / 2) - bgX - 85, (player.rc.top) - bgY - 30);
		}
		
		break;
	}

	sprintf(str, "%d", FALL);
	TextOut(getMemDC(), 10, 10, str, strlen(str));

	char strX[100];
	sprintf(strX, "%f", bgX);
	TextOut(getMemDC(), 10, 30, strX, strlen(strX));

	char strY[100];
	sprintf(strY, "%f", bgY); 
	TextOut(getMemDC(), 30, 60, strY, strlen(strY));


}

void grabWall::animation()
{
	switch (player.state)
	{
	case _IDLE:
		if (player.isRight)
		{
			frameCnt++;
			player_idle->setFrameY(0);
			if (frameCnt % 7 == 0)
			{
				frameIdx++;
				if (frameIdx > 11)
				{
					frameIdx = 0;
				}
				player_idle->setFrameX(frameIdx);
			}
		}
		else 
		{
			frameCnt++;
			player_idle->setFrameY(1);
			if (frameCnt % 7 == 0)
			{
				frameIdx--;
				if (frameIdx < 0)
				{
					frameIdx = 11;
				}
				player_idle->setFrameX(frameIdx);
			}
		}
		break;
	case _RUN:
		if (player.isRight)
		{
			frameCnt++;
			player_run->setFrameY(0);
			if (frameCnt % 5 == 0)
			{
				frameIdx++;
				if (frameIdx > 9)
				{
					frameIdx = 0;
				}
				player_run->setFrameX(frameIdx);
			}
		}
		else
		{
			frameCnt++;
			player_run->setFrameY(1);
			if (frameCnt % 5 == 0)
			{
				frameIdx--;
				if (frameIdx < 1)
				{
					frameIdx = 9;
				}
				player_run->setFrameX(frameIdx);
			}
		}
		break;
	case _JUMP:
		if (player.isRight)
		{
			frameCnt++;
			player_jump->setFrameY(0);
			if (frameCnt % 3 == 0)
			{
				frameIdx++;
				if (frameIdx > 10)
				{
					frameIdx = 0;
				}
				player_jump->setFrameX(frameIdx);
			}
		}
		else
		{
			frameCnt++;
			player_jump->setFrameY(1);
			if (frameCnt % 3 == 0)
			{
				frameIdx--;
				if (frameIdx < 1)
				{
					frameIdx = 10;
				}
				player_jump->setFrameX(frameIdx);
			}
		}
		break;
	case _FALL:
		if (player.isRight)
		{
			frameCnt++;
			player_fall->setFrameY(0);
			if (frameCnt % 4 == 0)
			{
				frameIdx++;
				if (frameIdx > 3)
				{
					frameIdx = 0;
				}
				player_fall->setFrameX(frameIdx);
			}
		}
		else
		{
			frameCnt++;
			player_fall->setFrameY(1);
			if (frameCnt % 4 == 0)
			{
				frameIdx--;
				if (frameIdx < 1)
				{
					frameIdx = 4;
				}
				player_fall->setFrameX(frameIdx);
			}
		}
		break;
	case _GRAB:
		if (player.isRight)
		{
			frameCnt++;
			player_grab->setFrameY(0);
			if (frameCnt % 4 == 0)
			{
				frameIdx++;
				if (frameIdx > 3)
				{
					frameIdx = 4;
				}
				player_grab->setFrameX(frameIdx);
			}
		}
		else
		{
			frameCnt++;
			player_grab->setFrameY(1);
			if (frameCnt % 4 == 0)
			{
				frameIdx--;
				if (frameIdx < 1)
				{
					frameIdx = 0;
				}
				player_grab->setFrameX(frameIdx);
			}
		}
		break;
	case _ATTACK:
		if (player.isRight)
		{
			frameCnt++;
			player.x += cosf(player.angle) * player.speed;
			player_attack->setFrameY(0);
			player_attack_shadow->setFrameY(0);
			player_attack_shadow2->setFrameY(0);
			player_attack_shadow3->setFrameY(0);
			player_slash->setFrameY(0);
			if (frameCnt % 4 == 0)
			{
				frameIdx++;
				slashFrameIdx++;
				shadowframeIdx1++;
				shadowframeIdx2++;
				shadowframeIdx3++;
				if (frameIdx > 7)
				{
					frameIdx = 0;
				}
				if (shadowframeIdx1 - 1 > 7)
				{
					shadowframeIdx1 = 0;
				}
				if (shadowframeIdx1 - 2 > 7)
				{
					shadowframeIdx1 = 0;
				}
				if (shadowframeIdx1 - 3 > 7)
				{
					shadowframeIdx1 = 0;
				}
				if (slashFrameIdx > 4)
				{
					slashFrameIdx = 6;
				}
				player_attack->setFrameX(frameIdx);
				player_attack_shadow->setFrameX(shadowframeIdx1-1);
				player_attack_shadow2->setFrameX(shadowframeIdx2 -2);
				player_attack_shadow3->setFrameX(shadowframeIdx3 -3);
				player_slash->setFrameX(slashFrameIdx);
			}
		}
		else
		{
			frameCnt++;
			player.x += cosf(player.angle) * player.speed;
			player_attack->setFrameY(1);
			player_slash->setFrameY(1);
			if (frameCnt % 3 == 0)
			{
				frameIdx--;
				slashFrameIdx--;
				if (frameIdx < 0)
				{
					frameIdx = 7;
				}
				if (slashFrameIdx < 0)
				{
					slashFrameIdx = 6;
				}
				player_attack->setFrameX(frameIdx);
				player_slash->setFrameX(slashFrameIdx);
			}
		}
		break;
	}
}

void grabWall::floorSet()
{
	player.state = _IDLE;
	FALL = false;
	JUMP = false;
	GRAB = false;
	jumpCount = 0;
	gravity = 0;
	player.y = WINSIZEY - player.height / 2;
}

void grabWall::pixelCollisionLeft()
{
	//�ȼ��浹 ����
	
		COLORREF color = GetPixel(bg_wall->getMemDC(), findleft + cosf(player.angle) * player.speed, player.y);
		int r = GetRValue(color);
		int g = GetGValue(color);
		int b = GetBValue(color);

		if (!(r == 255 && g == 0 && b == 255))
		{
			WALLCRASH_LEFT = true;
		}
		else
		{
			WALLCRASH_LEFT = false;
		}

}

void grabWall::pixelCollisionRight()
{
	//�ȼ��浹 ������
	
	COLORREF color2 = GetPixel(bg_wall->getMemDC(), findright + cosf(player.angle) * player.speed, player.y);
	int r2 = GetRValue(color2);
	int g2 = GetGValue(color2);
	int b2 = GetBValue(color2);

	if (!(r2 == 255 && g2 == 0 && b2 == 255))
	{
		WALLCRASH_RIGHT = true;
	}
	else
	{
		WALLCRASH_RIGHT = false;
	}
}

void grabWall::pixelCoiilsionBottom()
{
	//�ȼ��浹 ����

	COLORREF color3 = GetPixel(bg_wall->getMemDC(), player.x, findbottom + 10);
	int r3 = GetRValue(color3);
	int g3 = GetGValue(color3);
	int b3 = GetBValue(color3);

	if (!(r3 == 255 && g3 == 0 && b3 == 255))
	{
		WALLCRASH_BOTTOM = true;
		sprintf(str, "����");
	}
	else
	{
		WALLCRASH_BOTTOM = false;
	}

}

void grabWall::pixelCoiilsionTop()
{
	COLORREF color4 = GetPixel(bg_wall->getMemDC(), player.x, findtop - 20);
	int r4 = GetRValue(color4);
	int g4 = GetGValue(color4);
	int b4 = GetBValue(color4);
	
	if (!(r4 == 255 && g4 == 0 && b4 == 255))
	{
		WALLCRASH_TOP = true;
	}
	else
	{
		WALLCRASH_TOP = false;
	}
}
