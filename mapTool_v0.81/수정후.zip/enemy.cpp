#include "stdafx.h"
#include "enemy.h"

HRESULT enemy::init()
{

	return S_OK;
}

void enemy::release()
{
}

void enemy::update()
{
}

void enemy::render()
{
}
